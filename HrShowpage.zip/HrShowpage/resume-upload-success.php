<!DOCTYPE html>
<html>
  <head>
    <title>Resume Upload Success</title>
    <link rel="stylesheet" href="resume-upload-success.css">
  </head>
  <body>
    <h1>Resume Upload Success</h1>
    <p>Thank you for submitting your resume. We have received your information and will be in touch shortly.</p>
  </body>
</html>
